Step 1: You want to open the notepad of the program called CommandLineProgram.java
This contains my java code to run in the command prompt.
Step 2: Open Windows Subsystem for Linux command prompt, or the equivalence in Linux or MacOS.
Step 3: Compile the program by typing the following command and hit enter:
javac CommandLineProgram.java
(You may get this error when you try to compile the program: “javac’ 
is not recognized as an internal or external command, operable program or 
batch file“. This error occurs when the java path is not set in your system)
To do so you must set the path 
(for windows):
set path=C:\Program Files\Java\jdk1.8.0_121\bin
(for macOS):
export JAVA_HOME=/Library/Java/Home
echo $JAVA_HOME
Step 4: After the program is compiled, we can run the program. To run the program, type the
following command and hit enter:
java CommandLineProgram

** This program will take an input list text file and sort the names in the list by length, alphabetically, then reverse the list. 
** If you do not want to reverse the list, simply look in the main class and delete ONLY this portion:
//////////////////////////////////////////////////////////////////
//Save the reverse array in the inputList so that it prints it to the output correctly
inputList = reverseArrayList(inputList);

** now the program will just sort the names by length and alphabetically and not reverse it!